425 Sinhala functional words with,
29 conjuctions
76 determinents
35 ineterjections
145 particles
143 post positions

This resource is free for research and for producing software that is distributed under open source licenses. See the LGPL-LR license for more details: http://www.cnrtl.fr/lexiques/prolex/licence_lgpl-lr.php

For commercial use of this resource, please contact the address or email below.

Language Technology Research Laboratory,
University of Colombo School of Comparing,
No: 35, Reid Avenue,
Colombo 00700.

Web:	ltrl.ucsc.lk
email:	ltrl@ucsc.cmb.ac.lk
Phone:	011-2581245